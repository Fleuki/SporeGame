export class InputManager {
  constructor(canvas){
    this.keys={w:false,a:false,s:false,d:false};
    this.mouse={x:0,y:0};
    document.addEventListener("keydown",(e)=>{
      const k=e.key.toLowerCase();
      if(k in this.keys){ this.keys[k]=true; e.preventDefault(); }
      if(k==="m") this.onMutePress?.();
      if(k==="r") this.onRestartPress?.();
      if(k==="escape") this.onPausePress?.();
    });
    document.addEventListener("keyup",(e)=>{
      const k=e.key.toLowerCase();
      if(k in this.keys){ this.keys[k]=false; e.preventDefault(); }
    });
    canvas.addEventListener("mousemove",(e)=>{
      const rect=canvas.getBoundingClientRect();
      const sx=canvas.width/rect.width, sy=canvas.height/rect.height;
      this.mouse.x=Math.max(0,Math.min(canvas.width,(e.clientX-rect.left)*sx));
      this.mouse.y=Math.max(0,Math.min(canvas.height,(e.clientY-rect.top)*sy));
    });
    canvas.addEventListener("contextmenu",(e)=>e.preventDefault());
  }
}