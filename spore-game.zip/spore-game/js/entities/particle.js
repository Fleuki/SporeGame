import { rand } from '../utils/math.js';

export class ParticleSystem {
  constructor() {
    this.particles = [];
  }

  emit(x, y, color, count = 8, speedMin = 1, speedMax = 4) {
    for (let i = 0; i < count; i++) {
      const angle = rand(0, Math.PI * 2);
      const speed = rand(speedMin, speedMax);
      this.particles.push({
        x, y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        radius: rand(2, 5),
        life: 30 + rand(0, 20),
        maxLife: 50,
        color
      });
    }
  }

  update() {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.x += p.vx; p.y += p.vy;
      p.vx *= 0.97; p.vy *= 0.97;
      p.life--;
      if (p.life <= 0) this.particles.splice(i, 1);
    }
  }

  draw(renderer) {
    for (const p of this.particles) {
      const alpha = p.life / p.maxLife;
      renderer.ctx.globalAlpha = alpha;
      renderer.drawCircle(p.x, p.y, p.radius * alpha, p.color || '#ff8844');
    }
    renderer.ctx.globalAlpha = 1;
  }
}
