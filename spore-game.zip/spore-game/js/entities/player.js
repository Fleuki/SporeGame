import { clamp, angleTo } from '../utils/math.js';
import { CONFIG } from '../config.js';
import { Bullet } from './bullet.js';

export class Player {
  constructor(x, y) {
    this.x = x; this.y = y;
    this.radius = CONFIG.player.radius;
    this.speed = CONFIG.player.speed;
    this.maxHp = CONFIG.player.maxHp;
    this.hp = this.maxHp;
    this.xp = 0;
    this.level = 1;
    this.xpToNext = 10;
    this.damage = CONFIG.player.damage;
    this.attackCooldown = 0;
    this.attackRate = CONFIG.player.attackRate;
    this.angle = 0;
    this.color = CONFIG.player.color;
  }

  update(input, w, h) {
    let dx = 0, dy = 0;
    if (input.keys.w) dy = -1;
    if (input.keys.s) dy = 1;
    if (input.keys.a) dx = -1;
    if (input.keys.d) dx = 1;
    if (dx !== 0 && dy !== 0) { dx *= 0.707; dy *= 0.707; }
    this.x += dx * this.speed;
    this.y += dy * this.speed;
    this.x = clamp(this.x, this.radius, w - this.radius);
    this.y = clamp(this.y, this.radius, h - this.radius);
    this.angle = angleTo(this.x, this.y, input.mouse.x, input.mouse.y);
    if (this.attackCooldown > 0) this.attackCooldown--;
  }

  tryShoot() {
    if (this.attackCooldown <= 0) {
      this.attackCooldown = this.attackRate;
      return new Bullet(
        this.x + Math.cos(this.angle) * (this.radius + 4),
        this.y + Math.sin(this.angle) * (this.radius + 4),
        this.angle, this.damage
      );
    }
    return null;
  }

  takeDamage(amount) { this.hp -= amount; return this.hp <= 0; }

  addXp(amount) {
    this.xp += amount;
    let leveledUp = false;
    while (this.xp >= this.xpToNext) {
      this.xp -= this.xpToNext;
      this.level++;
      this.xpToNext = Math.floor(this.xpToNext * 1.4) + 4;
      this.damage += 2;
      this.maxHp += 10;
      this.hp = Math.min(this.hp + 20, this.maxHp);
      leveledUp = true;
    }
    return leveledUp;
  }

  draw(renderer) {
    const img = renderer.loader?.getImage(CONFIG.assets.images.player);
    if (img) {
      renderer.drawSprite(img, this.x, this.y, this.radius * 2.2, this.radius * 2.2, this.angle);
    } else {
      renderer.drawGradientCircle(this.x, this.y, this.radius, this.color.body);
      renderer.ctx.strokeStyle = this.color.stroke;
      renderer.ctx.lineWidth = 2;
      renderer.ctx.stroke();
    }

    for (let side = -1; side <= 1; side += 2) {
      const ex = this.x + Math.cos(this.angle + side * 0.5) * this.radius * 0.5;
      const ey = this.y + Math.sin(this.angle + side * 0.5) * this.radius * 0.5;
      renderer.drawCircle(ex, ey, 5, '#fff');
      renderer.drawCircle(ex + Math.cos(this.angle) * 3, ey + Math.sin(this.angle) * 3, 2.5, '#222');
    }

    renderer.ctx.beginPath();
    renderer.ctx.moveTo(
      this.x + Math.cos(this.angle) * this.radius,
      this.y + Math.sin(this.angle) * this.radius
    );
    renderer.ctx.lineTo(
      this.x + Math.cos(this.angle) * (this.radius + 14),
      this.y + Math.sin(this.angle) * (this.radius + 14)
    );
    renderer.ctx.strokeStyle = '#88ffaa';
    renderer.ctx.lineWidth = 3;
    renderer.ctx.stroke();

    const hpW = 120, hpH = 10, hpX = 20, hpY = 50;
    renderer.ctx.fillStyle = '#333';
    renderer.ctx.fillRect(hpX, hpY, hpW, hpH);
    renderer.ctx.fillStyle = this.hp / this.maxHp > 0.4 ? '#00ff44' : '#ff3333';
    renderer.ctx.fillRect(hpX, hpY, hpW * (this.hp / this.maxHp), hpH);
    renderer.ctx.strokeStyle = '#666';
    renderer.ctx.lineWidth = 1;
    renderer.ctx.strokeRect(hpX, hpY, hpW, hpH);
    renderer.drawText(`HP ${Math.floor(this.hp)}/${this.maxHp}`, hpX + 4, hpY + 9, { font: '11px monospace', color: '#aaa' });
  }
}
