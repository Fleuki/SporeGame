export class Bullet {
  constructor(x, y, angle, damage) {
    this.x = x; this.y = y;
    this.vx = Math.cos(angle) * 6;
    this.vy = Math.sin(angle) * 6;
    this.radius = 5;
    this.damage = damage;
    this.life = 120;
  }
  update() { this.x += this.vx; this.y += this.vy; this.life--; }
  isOffScreen(w, h) {
    return this.x < -20 || this.x > w + 20 || this.y < -20 || this.y > h + 20;
  }
  draw(renderer) {
    renderer.drawGradientCircle(this.x, this.y, this.radius, ['#aaffff', '#00aaff']);
    renderer.ctx.shadowBlur = 10;
    renderer.ctx.shadowColor = '#00aaff';
    renderer.ctx.fill();
    renderer.ctx.shadowBlur = 0;
  }
}
