import { angleTo } from '../utils/math.js';
import { CONFIG } from '../config.js';

export class Enemy {
  constructor(x, y, typeKey) {
    const type = CONFIG.enemies.types[typeKey] || CONFIG.enemies.types.slime;
    this.x = x; this.y = y;
    this.typeKey = typeKey;
    this.radius = type.radius;
    this.maxHp = type.hp;
    this.hp = this.maxHp;
    this.speed = type.speed;
    this.damage = type.damage;
    this.xpReward = type.xpReward;
    this.color = type.color;
    this.spriteKey = type.sprite;
  }

  update(player) {
    const a = angleTo(this.x, this.y, player.x, player.y);
    this.x += Math.cos(a) * this.speed;
    this.y += Math.sin(a) * this.speed;
  }

  takeDamage(amount) { this.hp -= amount; return this.hp <= 0; }

  draw(renderer) {
    const img = this.spriteKey ? renderer.loader?.getImage(this.spriteKey) : null;
    if (img) {
      renderer.drawSprite(img, this.x, this.y, this.radius * 2.5, this.radius * 2.5);
    } else {
      renderer.drawGradientCircle(this.x, this.y, this.radius, this.color?.body || ['#ff8844', '#992200']);
    }

    const ang = angleTo(this.x, this.y, renderer.playerX || 0, renderer.playerY || 0);
    for (let side = -1; side <= 1; side += 2) {
      const ex = this.x + Math.cos(ang + side * 0.4) * this.radius * 0.5;
      const ey = this.y + Math.sin(ang + side * 0.4) * this.radius * 0.5;
      renderer.drawCircle(ex, ey, this.radius * 0.25, '#fff');
      renderer.drawCircle(ex + Math.cos(ang) * 2, ey + Math.sin(ang) * 2, this.radius * 0.1, '#000');
    }

    const hpPct = this.hp / this.maxHp;
    renderer.ctx.fillStyle = '#333';
    renderer.ctx.fillRect(this.x - this.radius, this.y - this.radius - 8, this.radius * 2, 4);
    renderer.ctx.fillStyle = hpPct > 0.5 ? '#0f0' : '#f00';
    renderer.ctx.fillRect(this.x - this.radius, this.y - this.radius - 8, this.radius * 2 * hpPct, 4);
  }
}
