export class AssetLoader {
  constructor() {
    this.images = new Map();
    this.sounds = new Map();
    this.loaded = 0;
    this.total = 0;
  }

  loadImage(key, src) {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => { this.images.set(key, img); this.loaded++; resolve(img); };
      img.onerror = () => { console.warn('Не загрузилось:', src); resolve(null); };
      img.src = src;
      this.total++;
    });
  }

  loadSound(key, src) {
    return new Promise((resolve) => {
      const audio = new Audio();
      audio.oncanplaythrough = () => { this.sounds.set(key, audio); this.loaded++; resolve(audio); };
      audio.onerror = () => { console.warn('Не загрузился звук:', src); resolve(null); };
      audio.src = src;
      this.total++;
    });
  }

  getImage(key) { return this.images.get(key); }
  getSound(key) { return this.sounds.get(key); }

  async loadAll(configAssets) {
    const promises = [];
    for (const [key, path] of Object.entries(configAssets.images || {})) {
      promises.push(this.loadImage(key, path));
    }
    for (const [key, path] of Object.entries(configAssets.sounds || {})) {
      promises.push(this.loadSound(key, path));
    }
    await Promise.all(promises);
    console.log('Ассеты загружены:', this.loaded, '/', this.total);
  }
}
