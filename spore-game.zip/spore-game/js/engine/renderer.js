export class Renderer {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.loader = null;
    this.playerX = 0;
    this.playerY = 0;
  }

  clear() {
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
  }

  drawGrid(width, height, step = 40, color = '#1a1a2e') {
    this.ctx.strokeStyle = color;
    this.ctx.lineWidth = 1;
    for (let x = 0; x < width; x += step) {
      this.ctx.beginPath(); this.ctx.moveTo(x, 0); this.ctx.lineTo(x, height); this.ctx.stroke();
    }
    for (let y = 0; y < height; y += step) {
      this.ctx.beginPath(); this.ctx.moveTo(0, y); this.ctx.lineTo(width, y); this.ctx.stroke();
    }
  }

  drawGradientCircle(x, y, radius, colors) {
    if (!colors || colors.length < 2) colors = ['#fff', '#000'];
    const grad = this.ctx.createRadialGradient(x - 4, y - 4, 2, x, y, radius);
    colors.forEach((c, i) => grad.addColorStop(i / (colors.length - 1), c));
    this.ctx.beginPath();
    this.ctx.arc(x, y, radius, 0, Math.PI * 2);
    this.ctx.fillStyle = grad;
    this.ctx.fill();
  }

  drawCircle(x, y, radius, fill, stroke = null, lineWidth = 2) {
    this.ctx.beginPath();
    this.ctx.arc(x, y, radius, 0, Math.PI * 2);
    if (fill) { this.ctx.fillStyle = fill; this.ctx.fill(); }
    if (stroke) { this.ctx.strokeStyle = stroke; this.ctx.lineWidth = lineWidth; this.ctx.stroke(); }
  }

  drawHealthBar(x, y, w, h, hp, maxHp, low = '#f00', high = '#0f0', bg = '#333') {
    const pct = hp / maxHp;
    this.ctx.fillStyle = bg;
    this.ctx.fillRect(x - w / 2, y - h / 2, w, h);
    this.ctx.fillStyle = pct > 0.5 ? high : low;
    this.ctx.fillRect(x - w / 2, y - h / 2, w * pct, h);
  }

  drawText(text, x, y, opts = {}) {
    this.ctx.font = opts.font || '16px monospace';
    this.ctx.fillStyle = opts.color || '#aaa';
    this.ctx.textAlign = opts.align || 'left';
    this.ctx.fillText(text, x, y);
  }

  drawSprite(img, x, y, width, height, angle = 0) {
    if (!img) return;
    this.ctx.save();
    this.ctx.translate(x, y);
    this.ctx.rotate(angle);
    this.ctx.drawImage(img, -width / 2, -height / 2, width, height);
    this.ctx.restore();
  }

  drawOverlay(alpha) {
    this.ctx.fillStyle = `rgba(0,0,0,${alpha})`;
    this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
  }
}
