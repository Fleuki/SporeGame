import { CONFIG } from './config.js';
import { AssetLoader } from './engine/assetLoader.js';
import { AudioManager } from './engine/audio.js';
import { InputManager } from './engine/input.js';
import { Renderer } from './engine/renderer.js';
import { Player } from './entities/player.js';
import { ParticleSystem } from './entities/particle.js';
import { WaveSystem } from './systems/waveSystem.js';

const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
canvas.width = CONFIG.screen.width;
canvas.height = CONFIG.screen.height;

const loader = new AssetLoader();
const audio = new AudioManager(loader);
const input = new InputManager(canvas);
const renderer = new Renderer(canvas);
renderer.loader = loader;
const particles = new ParticleSystem();

input.onMutePress = () => { audio.toggleMute(); };
input.onRestartPress = () => { if (gameOver) init(); };

(async () => {
  await loader.loadAll(CONFIG.assets);
})();

let player, enemies, bullets, waveSystem, gameOver;

function init() {
  player = new Player(CONFIG.screen.width / 2, CONFIG.screen.height / 2);
  enemies = [];
  bullets = [];
  waveSystem = new WaveSystem(CONFIG.screen.width, CONFIG.screen.height);
  waveSystem.startWave();
  gameOver = false;
}

function update() {
  if (gameOver) return;
  player.update(input, CONFIG.screen.width, CONFIG.screen.height);

  const bullet = player.tryShoot();
  if (bullet) { bullets.push(bullet); }

  waveSystem.update(enemies, player);

  for (let i = enemies.length - 1; i >= 0; i--) {
    const e = enemies[i];
    e.update(player);
    const d = Math.hypot(e.x - player.x, e.y - player.y);
    if (d < e.radius + player.radius) {
      player.takeDamage(e.damage * 0.3);
      e.hp -= 5;
      if (player.hp <= 0) { player.hp = 0; gameOver = true; }
      const pushAngle = Math.atan2(e.y - player.y, e.x - player.x);
      e.x += Math.cos(pushAngle) * 8;
      e.y += Math.sin(pushAngle) * 8;
    }
    if (e.hp <= 0) {
      particles.emit(e.x, e.y, '#ff6633', 10);
      if (player.addXp(e.xpReward)) {
        particles.emit(player.x, player.y, '#00ff88', 20);
      }
      enemies.splice(i, 1);
    }
  }

  for (let i = bullets.length - 1; i >= 0; i--) {
    const b = bullets[i];
    b.update();
    let hit = false;
    for (const e of enemies) {
      if (Math.hypot(b.x - e.x, b.y - e.y) < b.radius + e.radius) {
        e.takeDamage(b.damage);
        particles.emit(b.x, b.y, '#88ff88', 5);
        hit = true; break;
      }
    }
    if (hit || b.isOffScreen(CONFIG.screen.width, CONFIG.screen.height) || b.life <= 0) {
      bullets.splice(i, 1);
    }
  }

  particles.update();
  document.getElementById('xpDisplay').textContent = Math.floor(player.xp);
  document.getElementById('levelDisplay').textContent = player.level;
  document.getElementById('enemyCount').textContent = enemies.length;
}

function draw() {
  renderer.clear();
  renderer.drawGrid(CONFIG.screen.width, CONFIG.screen.height);
  renderer.playerX = player.x;
  renderer.playerY = player.y;

  for (const e of enemies) e.draw(renderer);
  for (const b of bullets) b.draw(renderer);
  particles.draw(renderer);
  player.draw(renderer);

  renderer.drawText(`Уровень ${player.level}  |  XP ${Math.floor(player.xp)}/${player.xpToNext}`, 20, 30, { font: '14px monospace', color: '#aaa' });
  renderer.drawText(`Волна ${waveSystem.wave}  |  Врагов: ${enemies.length}`, CONFIG.screen.width - 220, 30, { font: '16px monospace', color: '#8888ff' });

  if (gameOver) {
    renderer.drawOverlay(0.7);
    renderer.drawText('GAME OVER', CONFIG.screen.width / 2, CONFIG.screen.height / 2 - 20, { font: 'bold 60px monospace', color: '#ff3344', align: 'center' });
    renderer.drawText(`Волна ${waveSystem.wave} | Уровень ${player.level}`, CONFIG.screen.width / 2, CONFIG.screen.height / 2 + 50, { font: '20px monospace', color: '#aaa', align: 'center' });
    renderer.drawText('R — рестарт | M — звук', CONFIG.screen.width / 2, CONFIG.screen.height / 2 + 100, { font: '16px monospace', color: '#888', align: 'center' });
  }
}

function gameLoop() {
  update();
  draw();
  requestAnimationFrame(gameLoop);
}

init();
gameLoop();
console.log('Spore Survivor модульная запущена! WASD — движение, мышь — направление, M — звук, R — рестарт');
