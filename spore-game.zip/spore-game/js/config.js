// ============================================
// ВСЕ настройки игры в одном месте.
// Меняй тут — не лезь в логику!
// ============================================

export const CONFIG = {
  screen: { width: 800, height: 600 },

  player: {
    radius: 14,
    speed: 3.2,
    maxHp: 100,
    damage: 8,
    attackRate: 12,
    sprite: null,
    color: {
      body: ['#66ff99', '#00aa44', '#004422'],
      stroke: '#88ffaa'
    }
  },

  enemies: {
    types: {
      slime: {
        name: 'Слизь',
        hp: 20, speed: 0.8, radius: 12, damage: 10, xpReward: 5,
        color: { body: ['#ff8844', '#992200'] },
        sprite: null
      },
      runner: {
        name: 'Бегун',
        hp: 15, speed: 1.5, radius: 10, damage: 8, xpReward: 8,
        color: { body: ['#ff44ff', '#660066'] },
        sprite: null
      },
      tank: {
        name: 'Танк',
        hp: 80, speed: 0.4, radius: 20, damage: 20, xpReward: 20,
        color: { body: ['#888888', '#333333'] },
        sprite: null
      },
      boss: {
        name: 'Босс',
        hp: 300, speed: 0.6, radius: 35, damage: 35, xpReward: 100,
        color: { body: ['#ff0000', '#550000'] },
        sprite: null
      }
    }
  },

  waves: {
    baseEnemies: 4,
    enemyMultiplier: 1.8,
    spawnIntervalBase: 40,
    spawnIntervalMin: 12,
    delayBetweenWaves: 30
  },

  assets: {
    images: {},
    sounds: {}
  }
};
