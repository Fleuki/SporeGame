import { CONFIG } from '../config.js';
import { Enemy } from '../entities/enemy.js';
import { rand } from '../utils/math.js';

export class WaveSystem {
  constructor(w, h) {
    this.w = w; this.h = h;
    this.wave = 1;
    this.enemiesPerWave = CONFIG.waves.baseEnemies;
    this.spawnTimer = 0;
    this.spawnInterval = CONFIG.waves.spawnIntervalBase;
    this.enemiesSpawned = 0;
    this.waveDelay = 0;
    this.active = true;
  }

  startWave() {
    this.wave++;
    this.enemiesPerWave = Math.floor(CONFIG.waves.baseEnemies + this.wave * CONFIG.waves.enemyMultiplier);
    this.spawnInterval = Math.max(CONFIG.waves.spawnIntervalMin, CONFIG.waves.spawnIntervalBase - this.wave * 1.5);
    this.enemiesSpawned = 0;
    this.waveDelay = CONFIG.waves.delayBetweenWaves;
  }

  update(enemies, player) {
    if (!this.active) return;
    if (this.waveDelay > 0) { this.waveDelay--; return; }
    if (this.enemiesSpawned < this.enemiesPerWave) {
      this.spawnTimer--;
      if (this.spawnTimer <= 0) {
        this.spawnEnemy(enemies);
        this.enemiesSpawned++;
        this.spawnTimer = this.spawnInterval;
      }
    } else if (enemies.length === 0) {
      this.startWave();
    }
  }

  spawnEnemy(enemies) {
    const side = Math.floor(Math.random() * 4);
    const pad = 30;
    let x, y;
    if (side === 0) { x = rand(-pad, this.w + pad); y = -pad; }
    else if (side === 1) { x = this.w + pad; y = rand(-pad, this.h + pad); }
    else if (side === 2) { x = rand(-pad, this.w + pad); y = this.h + pad; }
    else { x = -pad; y = rand(-pad, this.h + pad); }

    let type = 'slime';
    if (this.wave > 3) type = Math.random() > 0.6 ? 'runner' : 'slime';
    if (this.wave > 6) {
      const r = Math.random();
      if (r > 0.7) type = 'tank';
      else if (r > 0.4) type = 'runner';
    }
    if (this.wave % 10 === 0 && this.wave > 0) type = 'boss';

    enemies.push(new Enemy(x, y, type));
  }

  reset() { this.wave = 0; this.startWave(); }
}
