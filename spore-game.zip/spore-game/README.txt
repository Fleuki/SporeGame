============================================
  Spore Survivor — Модульная версия
============================================

КАК ЗАПУСТИТЬ:
  1. Распакуй spore-game.zip
  2. Запусти локальный сервер в папке spore-game/:
       python -m http.server 8000
     или открой index.html через Live Server в VS Code
  3. Открой http://localhost:8000

ВАЖНО: из-за ES6 модулей (type="module") НЕЛЬЗЯ просто
открыть index.html двойным кликом — нужен локальный сервер!

============================================
КАК ДОБАВИТЬ СВОИ АССЕТЫ
============================================

1. СПРАЙТ ИГРОКА (вместо цветного круга):
   Положи PNG → assets/images/player/hero.png
   В js/config.js:
     player: { sprite: 'assets/images/player/hero.png', ... }
   Перезагрузи страницу.

2. СПРАЙТ ВРАГА:
   Положи PNG → assets/images/enemies/slime.png
   В js/config.js в enemies.types.slime:
     sprite: 'assets/images/enemies/slime.png'

3. ФОН (вместо сетки):
   Положи картинку → assets/images/backgrounds/dungeon.png
   В js/config.js:
     assets: { images: { bg: 'assets/images/backgrounds/dungeon.png' }}
   В js/main.js в draw() замени:
     renderer.drawGrid(...)
   на:
     const bg = renderer.loader.getImage('bg');
     if (bg) renderer.ctx.drawImage(bg, 0, 0, canvas.width, canvas.height);

4. МУЗЫКА:
   Положи OGG/MP3 → assets/sounds/music/battle.ogg
   В js/config.js:
     assets: { sounds: { bgm: 'assets/sounds/music/battle.ogg' }}
   В js/main.js раскомментируй:
     audio.playMusic('bgm');

5. ЗВУКИ (выстрел, попадание, левел-ап):
   Добавь пути в config.js → assets.sounds
   Раскомментируй audio.playSfx('...') в main.js

============================================
КАК ДОБАВИТЬ НОВОГО ВРАГА
============================================

Просто открой js/config.js, найди enemies.types и добавь:

  ghost: {
    name: 'Призрак',
    hp: 30, speed: 2.0, radius: 14, damage: 12, xpReward: 15,
    color: { body: ['#aaddff', '#004488'] },
    sprite: null
  }

Потом в js/systems/waveSystem.js в spawnEnemy() добавь:
  if (this.wave > 8 && Math.random() > 0.7) type = 'ghost';

============================================
КОРОТКИЕ ПРОМПТЫ ДЛЯ БОТОВ В ТЕЛЕГРАМ
============================================

Не кидай целые файлы. Кидай так:

  [ФАЙЛ: js/config.js]
  Добавь врага "Ghost", hp:30, speed:2.0,
  способность: 30% шанс уклониться от пули

  [ФАЙЛ: js/systems/waveSystem.js]
  Каждые 5 волн спавни 1 элитного врага
  с золотым ободком и х2 HP

  [ФАЙЛ: js/entities/player.js]
  Добавь второе оружие — дробовик:
  3 пули в веере ±15°, переключение на цифры 1/2

  [ФАЙЛ: js/main.js]
  Добавь меню на ESC: Продолжить, Рестарт, Выйти

  [ФАЙЛ: js/engine/renderer.js]
  Добавь метод drawBar(x,y,w,h,value,max,color)
  для красивых полосок опыта и HP

============================================
